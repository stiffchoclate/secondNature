@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.secondnature

import com.example.secondnature.navigation.Screen
import com.example.secondnature.navigation.SetupNavGraph
import androidx.compose.foundation.Image
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.compose.*


@Composable
//Stateless composable for the Dashboard screen.
fun DashBoardScreen(screenName: String, currentScore:Int, navController: NavController){
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ){
        Scaffold (
            topBar = { ScreenAppBar(screenName) }
        ){ innerPadding ->
            Dashboard(
                currentScore = currentScore,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                navController = navController
            )
        }
    }
}

//Stateless top app bar reusable for all app screens
@Composable
fun ScreenAppBar(screenName:String){
    CenterAlignedTopAppBar(
        title = {Text(
            text=screenName,
            fontSize = 30.sp,
        )},
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = when (isSystemInDarkTheme()){
                true -> md_theme_dark_primaryContainer
                else -> md_theme_light_primaryContainer
            } ,
            titleContentColor = when (isSystemInDarkTheme()){
                true -> md_theme_dark_onPrimaryContainer
                else -> md_theme_light_onPrimaryContainer
            },
            scrolledContainerColor = when (isSystemInDarkTheme()){
                true -> md_theme_dark_primaryContainer
                else -> md_theme_light_primaryContainer
            },
            navigationIconContentColor = when(isSystemInDarkTheme()){
                true -> Color.White
                else -> Color.Black
            },
            actionIconContentColor = when(isSystemInDarkTheme()){
                true -> Color.White
                else -> Color.Black
            },
        ),
        navigationIcon = {
            IconButton(
                onClick = {/*do something */},
                content = {
                    Icon(
                        painter = painterResource(R.drawable.baseline_menu_24) ,
                        contentDescription = null,
                        modifier = Modifier.padding(8.dp)
                    )
                },
            )
        }

    )
}

@Composable
//Stateless dashboard elements with no app bar
fun Dashboard(modifier:Modifier, currentScore:Int, navController: NavController){

    var clicks by remember{ mutableIntStateOf(0) }

    Column (modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top){
        CurrentScoreCard(currentScore)

        SectionNavigationButton("Achievements", navController)//Trophy Icon
        SectionNavigationButton("Food Diary", navController)//Diary or lines icon
        SectionNavigationButton("Settings", navController)//gear icon
        SectionNavigationButton("Goals", navController) //target icon

        Text(text = "$clicks so far." )
    }
}

@Composable
fun SectionNavigationButton(name:String, navController: NavController){
    val painterResource  = when (name){
        "Achievements" -> R.drawable.trophy_icon
        "Food Diary" -> R.drawable.menu_book_24px
        "Settings" -> R.drawable.settings_24px
        else -> R.drawable.workspace_premium_24px//goals
    }
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = Alignment.CenterStart,
    ){
        Button(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 8.dp, end = 8.dp),
            onClick = {
                when (name) {
                    "Settings" -> navController.navigate(route = Screen.Settings.route)
                }
            },
            shape = RoundedCornerShape(23.dp),
        ){

            Image(
                painter = painterResource(painterResource),
                contentDescription = "Trophy",
                modifier = Modifier,
            )
            Text(text = "$name")
        }

    }
}

@Composable
fun CurrentScoreCard(currentScore:Int) {
    lateinit var dashboardMessage: String

    when (currentScore) {
        in (0..40) -> dashboardMessage = "Having trouble sticking to your goals? Take a look at your food diary to see what the issue is."
        in (41..60) -> dashboardMessage = "Keep it up & you might just get a award for it ;)"
        in (61..80) -> dashboardMessage = "WOW!! Keep this up and and you could be lookng at gold or silver this week!"
        else -> dashboardMessage = "We see you going for the gold. Keep it up. There may be a platinum in your future..."
    }

    Column(modifier = Modifier,
        horizontalAlignment = Alignment.CenterHorizontally)
    {
        Card (modifier = Modifier
            .fillMaxWidth(0.8f) // 80% of entire screen width leftover from other composables
            .padding(8.dp),
        ){
            Column(modifier = Modifier
                .align(Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.SpaceEvenly)
            {
                Text(
                    modifier = Modifier.align(Alignment.CenterHorizontally),
                    textAlign = TextAlign.Center,
                    fontSize = 26.sp,
                    text = "Score",
                )
                Text(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally),
                    textAlign = TextAlign.Center,
                    fontSize = 120.sp,
                    color = colorResource(R.color.purple_200),
                    text = currentScore.toString(),
                )
                Text(
                    text = dashboardMessage,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally),
                    textAlign = TextAlign.Center,
                    fontSize = 12.sp,
                )
            }

        }
    }
}

@Preview(showBackground = true)
@Composable
fun Preview() {
    //using AppTheme{...} to wrap your composable will apply the default theming
    AppTheme{
        var navController = rememberNavController()
        SetupNavGraph(navController)
        DashBoardScreen(currentScore = 99, screenName = "Dashboard", navController = navController)
    }
}