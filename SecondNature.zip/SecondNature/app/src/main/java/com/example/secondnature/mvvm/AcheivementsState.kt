package com.example.secondnature.mvvm

data class AcheivementsState(
    val achievements: List<Achievements>,
    val award: String,
    val startDate: Long,
    val endDate: Long
)
