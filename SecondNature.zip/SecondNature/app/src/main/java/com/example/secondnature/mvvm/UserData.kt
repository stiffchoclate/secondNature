package com.example.secondnature.mvvm

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class UserData(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String = "User",
    val calorieGoal: Int = 0,
)