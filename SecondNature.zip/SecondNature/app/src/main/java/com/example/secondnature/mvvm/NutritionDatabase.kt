package com.example.secondnature.mvvm

import androidx.room.Database
import androidx.room.RoomDatabase

//how the database is structured


@Database(
    entities = [NutritionLog::class, UserData::class, Achievements::class],
    version = 2
)
//allows viewModel to update state and UI.
abstract class NutritionDatabase: RoomDatabase() {

    abstract val nutritionLogDao: NutritionDao
}

