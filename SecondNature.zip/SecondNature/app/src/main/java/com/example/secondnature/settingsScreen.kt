package com.example.secondnature

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import com.example.compose.AppTheme

@Composable
fun SettingsScreenPlaceholder(modifier: Modifier = Modifier){
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ){
        Column(modifier = Modifier.fillMaxSize()){
            Text(
                text = "Settings",
                fontSize = 24.sp,)

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.CenterStart,
            ){
                Button(
                    onClick = {},
                    modifier = modifier,
                    content = { Text(text = "Dashboard") }
                )
            }
        }
    }

}


@Preview(showBackground = true)
@Composable
fun SettingsPreview(){
    AppTheme{
        // A surface container using the 'background' color from the theme
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            SettingsScreenPlaceholder()
        }
    }
}