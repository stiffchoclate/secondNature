package com.example.secondnature.mvvm

//State should have default values.
data class UserDataState(
    val userdata: List<UserData> = emptyList(),
    val name: String = "",
    val calorieGoal: Int = 0
)
