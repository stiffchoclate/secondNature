package com.example.secondnature.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.secondnature.DashBoardScreen
import com.example.secondnature.SettingsScreenPlaceholder

@Composable
fun SetupNavGraph(navController: NavHostController){
    //responsible for defining the home screen
    //use rememberSavable to persist the NavGraph through lifecycle
    NavHost(
        navController = navController,
        startDestination = Screen.Dashboard.route
    ){
        //All nodes/destinations/screens within the navigation graph.
        composable(route = Screen.Dashboard.route){
            DashBoardScreen(screenName = "Dashboard", 99, navController = navController)
        }
        composable(route = Screen.Settings.route){
            SettingsScreenPlaceholder(modifier = Modifier)
        }
        composable(route = Screen.FoodDiary.route ){}
        composable(route = Screen.Goals.route){}
        composable(route = Screen.Achievements.route){}
    }
}