package com.example.secondnature

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.*
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.example.compose.AppTheme
import com.example.secondnature.mvvm.NutritionDatabase
import com.example.secondnature.mvvm.NutritionViewModel
import com.example.secondnature.view.FoodDiaryScreen

//import com.example.secondnature.ui.theme.SecondNatureTheme

class MainActivity : ComponentActivity() {

    private val db by lazy {
        Room.databaseBuilder(
            applicationContext,
            NutritionDatabase::class.java,
            "nutrition.db"
        ).build()
    }
    private val viewModel by viewModels<NutritionViewModel>(
        factoryProducer = {
            object : ViewModelProvider.Factory {
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return NutritionViewModel(db.nutritionLogDao) as T
                }
            }
        }
    )



//    lateinit var navController: NavHostController
    //lateinit var userInfoViewModel: UserInfoViewModel

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //consider activity lifecycle to determine how to treat ViewModel when events occur
        setContent {
            AppTheme{
//                navController = rememberNavController()
//                SetupNavGraph(navController = navController)
                val state by viewModel.state.collectAsState()
                FoodDiaryScreen(onEvent = viewModel::onEvent, state = state)
            }
        }
    }
}
