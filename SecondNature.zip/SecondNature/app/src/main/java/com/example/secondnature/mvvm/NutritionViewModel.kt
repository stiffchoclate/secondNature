package com.example.secondnature.mvvm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

//State holder - hoists state using a Kotlin FLow.
class NutritionViewModel(
    private val nutritionDao: NutritionDao
) : ViewModel() {

    //_state is used to acc update db
    //state - public so that state can be collected before UI changes.
    private val _state = MutableStateFlow(FoodDiaryState())
    val state: StateFlow<FoodDiaryState> = _state.asStateFlow()


    //validation functions for logs to ensure data is valid

    //event-handler
    //its alot of events in one fucn to check through
    //could be source of crash
    fun onEvent(event: NutritionEvent) {
        when (event) {
        //every event must be specific i.e. a change in one field
        //change should be reported to view
        //some events will cause dao operations to occur

            NutritionEvent.ShowLogPage -> {
                _state.update { it.copy(
                    isLoggingFood = true //this change in state causes recomposition
                    )
                }
            }
            NutritionEvent.HideLogPage -> {
                _state.update { it.copy(
                    isLoggingFood = false
                ) }
            }

            is NutritionEvent.SaveLog ->{
                val name = state.value.name
                val protein = state.value.protein
                val fats = state.value.fats
                val carbs = state.value.carbs
                val transFats = state.value.transFats
                val iron = state.value.iron
                val vitaminA = state.value.vitaminA
                val date = {if (state.value.date?.toInt() != 0){ state.value.date }
                else {LocalDate.now().toEpochDay()}}

                viewModelScope.launch {
                    nutritionDao.upsertLog(
                        name = name,
                        iron = iron,
                        date = date(),
                        protein = protein,
                        carbs = carbs,
                        fats = fats,
                        transFats = transFats,
                        vitaminA = vitaminA,
                        calorieGoal = 0,
                        //implement logId autogenerate properly
                    )
                }

                _state.update { it.copy(
                    isLoggingFood = false,
                    name = "",
                    date = 0,
                    protein = 0,
                    carbs = 0,
                    fats = 0,
                    logs = emptyList(),
                    iron = 0,
                    transFats = 0,
                    vitaminA = 0
                ) }
            }

            NutritionEvent.GoToAchievements -> TODO()
            NutritionEvent.GoToDashboard -> TODO()

            is NutritionEvent.SetName -> {
                _state.update { it.copy(
                    name = event.new_name // the event is an object and it has a property as specified in the interface
                ) }
            }
            is NutritionEvent.SetCarbs -> {
               _state.update { it.copy(
                   carbs = event.new_carbs
               ) }
            }
            is NutritionEvent.SetFats -> {
                _state.update { it.copy(
                    fats = event.new_fats
                ) }
            }
            is NutritionEvent.SetIron -> {
                _state.update { it.copy(
                    iron = event.new_iron
                ) }
            }
            is NutritionEvent.SetProtein -> {
                _state.update { it.copy(
                    protein = (event.new_protein).toInt()
                ) }
            }
            is NutritionEvent.SetTransFats -> {
                _state.update { it.copy(
                    transFats = event.new_transFats
                ) }
            }
            is NutritionEvent.SetVitaminA -> {
                _state.update { it.copy(
                    vitaminA = event.new_vitaminA
                ) }
            }
        }
//    }
    }
}