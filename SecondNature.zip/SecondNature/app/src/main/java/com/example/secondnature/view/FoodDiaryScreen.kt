package com.example.secondnature.view

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.sp
import com.example.compose.md_theme_dark_onPrimaryContainer
import com.example.compose.md_theme_dark_primaryContainer
import com.example.compose.md_theme_light_onPrimaryContainer
import com.example.compose.md_theme_light_primaryContainer
import com.example.secondnature.R
import com.example.secondnature.mvvm.*


@Composable
@OptIn(ExperimentalMaterial3Api::class)
@ExperimentalMaterial3Api
fun FoodDiaryScreen(
    onEvent: (NutritionEvent) -> Unit,
    state: FoodDiaryState
) {

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(text = "Food Diary", fontSize = 30.sp) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = when (isSystemInDarkTheme()){
                        true -> md_theme_dark_primaryContainer
                        else -> md_theme_light_primaryContainer
                    } ,
                    titleContentColor = when (isSystemInDarkTheme()){
                        true -> md_theme_dark_onPrimaryContainer
                        else -> md_theme_light_onPrimaryContainer
                    },
                    scrolledContainerColor = when (isSystemInDarkTheme()){
                        true -> md_theme_dark_primaryContainer
                        else -> md_theme_light_primaryContainer
                    },
                    navigationIconContentColor = when(isSystemInDarkTheme()){
                        true -> Color.White
                        else -> Color.Black
                    },
                    actionIconContentColor = when(isSystemInDarkTheme()){
                        true -> Color.White
                        else -> Color.Black
                    },
                ),
                navigationIcon = {
                    IconButton(
                        onClick = {/*TODO()*/},
                        content = {
                            Icon(
                                painter = painterResource(id = R.drawable.baseline_event_24),
                                contentDescription = "Select date."
                                )
                        },
                        colors = IconButtonDefaults.outlinedIconButtonColors()
                    )
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {onEvent(NutritionEvent.ShowLogPage)},
            ){
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Log",
                )
            }
        },

    ) {innerPadding ->
        LazyColumn (
            modifier = Modifier.padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ){
            item{
                Text(text = "smn useful")
                if (state.isLoggingFood){
                    LogPage(state = state, onEvent = onEvent)
                }
            }

        }
    }
}
