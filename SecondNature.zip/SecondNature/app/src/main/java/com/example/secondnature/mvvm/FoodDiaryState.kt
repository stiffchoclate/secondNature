package com.example.secondnature.mvvm

//carries state through UDF cycle. i.e. UI State -> VM -> Model -> VM -> UI state
data class FoodDiaryState(
    val logs: List<NutritionLog> = emptyList(), //converts data class object to list
    val isLoggingFood: Boolean = false,
    val name: String? = "",
    val date: Long? = 0, //using LocalDate
    val protein: Int? = 0,
    val carbs: Int? = 0,
    val fats: Int? = 0,
    val iron: Int? = 0,
    val transFats: Int? = 0,
    val vitaminA: Int? = 0,
)
