package com.example.secondnature.mvvm

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Achievements(
    @PrimaryKey (autoGenerate = true)
    val id:Int = 0,
    val award: String = "",
    val startDate: Long = 0
)