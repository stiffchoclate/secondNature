package com.example.secondnature.view

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.secondnature.mvvm.NutritionEvent
import com.example.secondnature.mvvm.FoodDiaryState

@Composable
@ExperimentalMaterial3Api
fun LogPage(
    state: FoodDiaryState,
    onEvent: (NutritionEvent) -> Unit)
{
    AlertDialog(
        title = { Text(text = "Nutritional Details") },
        onDismissRequest = { onEvent(NutritionEvent.HideLogPage) },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceEvenly,
            ) {

                OutlinedTextField(
                    value = state.name!!, //edits public version to keep state safe
                    onValueChange = {
                        onEvent(NutritionEvent.SetName(it))
                        Log.d( "Name Field Change", "entering new string value into the field.")
                    },
                    label = { Text(text = "Name") },
                    singleLine = true,
                    maxLines = 1,
                )
                Spacer(modifier = Modifier.fillMaxWidth().height(8.dp))
                OutlinedTextField(
                    value = state.protein.toString(), //edits public version to keep state safe
                    onValueChange = {
                        if (it.isEmpty()) {
                            Log.d( "Protein Field Change", "entering new value into the field.")
                            onEvent(NutritionEvent.SetProtein(0))
                        }
                        else{
                            val n = it.toInt()
                            Log.d( "Protein Field Change", "entering new string value into the field.")
                            onEvent(NutritionEvent.SetProtein(it.toInt()))
                        }
                    },
                    label = { Text(text = "Protein") },
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(modifier = Modifier.fillMaxWidth().height(8.dp))
                OutlinedTextField(
                    value = state.carbs.toString(), //edits public version to keep state safe
                    onValueChange = {
                        if (it.isEmpty()){
                            Log.d( "Carbs Field Change", "entering new value into the field.")
                            onEvent(NutritionEvent.SetCarbs(0))
                        }
                        else{
                            val n = it.toInt()
                            Log.d( "Carbs Field Change", "entering new value into the field.")
                            onEvent(NutritionEvent.SetCarbs(it.toInt()))
                        }
                    },
                    label = { Text(text = "Carbs") },
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(modifier = Modifier.fillMaxWidth().height(8.dp))
                OutlinedTextField(
                    value = state.vitaminA.toString(), //edits public version to keep state safe
                    onValueChange = {
                        if (it.isEmpty()){
                            Log.d( "Vitamin A Field Change", "entering new string value into the field.")
                            onEvent(NutritionEvent.SetVitaminA(0))
                        }
                        else{
                            val n = it.toInt()
                            Log.d( "Vitamin A Field Change", "entering new string value into the field.")
                            onEvent(NutritionEvent.SetVitaminA(it.toInt()))
                        }
                    },
                    label = { Text(text = "Vitamin A") },
                    singleLine = true,
                    maxLines = 1,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(modifier = Modifier.fillMaxWidth().height(8.dp))
                OutlinedTextField(
                    value = state.fats.toString(),
                    onValueChange = {
                        if (it.isEmpty()){
                            Log.d( "" +
                                    "Fats Field Change", "entering new string value into the field.")
                            onEvent(NutritionEvent.SetFats(0))
                        }
                        else{
                            val n = it.toInt()
                            Log.d( "Fats Field Change", "entering new string value into the field.")
                            onEvent(NutritionEvent.SetFats(it.toInt()))
                        }
                    },
                    label = {Text("Fats")},
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    maxLines = 1,
                )
                Spacer(modifier = Modifier.fillMaxWidth().height(8.dp))
                OutlinedTextField(
                    value = state.transFats.toString(),
                    onValueChange = {
                        if (it.isEmpty()){
                            Log.d( "T-Fats Field Change", "entering new string value into the field.")
                            onEvent(NutritionEvent.SetTransFats(0))
                        }
                        else{
                            val n = it.toInt()
                            Log.d( "T-Fats Field Change", "entering new string value into the field.")
                            onEvent(NutritionEvent.SetTransFats(it.toInt()))
                        }
                    },
                    label = {Text("Trans Fats")},
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    maxLines = 1,
                )
                Spacer(modifier = Modifier.fillMaxWidth().height(8.dp))
                OutlinedTextField(
                    value = state.iron.toString(),
                    onValueChange = {
                        if (it.isEmpty()){
                            Log.d( "Iron Field Change", "entering new string value into the field.")
                            onEvent(NutritionEvent.SetIron(0))
                        }
                        else{
                            val n = it.toInt()
                            Log.d( "Iron Field Change", "entering new string value into the field.")
                            onEvent(NutritionEvent.SetIron(it.toInt()))
                        }
                    },
                    label = {Text("Iron")},
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    maxLines = 1,
                )
            }
        },
        confirmButton = {
            Box(
                contentAlignment = Alignment.Center,
            ){
                FilledTonalButton(
                    onClick = { onEvent(NutritionEvent.SaveLog) },
                    content = { Text("Save log") }
                )
            }
        },
    )
}