package com.example.secondnature.navigation

sealed class Screen(val route: String) {
    object Dashboard: Screen(route = "Dashboard_Screen")
    object Settings: Screen(route = "Settings_Screen")
    object Goals: Screen(route = "Goals_Screen")
    object FoodDiary: Screen(route = "Food_Diary_Screen")
    object Achievements: Screen(route = "Achievements_Screen")
}