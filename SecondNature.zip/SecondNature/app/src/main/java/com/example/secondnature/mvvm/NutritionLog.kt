package com.example.secondnature.mvvm

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.sql.Time
import java.sql.Date

//Entity refers to a table in a DB essentially.
@Entity
data class NutritionLog( // this is table name
    val name: String? = "",
    val date: Long? = 0, //data type subject to change

    val protein: Int?,
    val carbs: Int?,
    val fats: Int?,

    val iron: Int?,
    val transFats: Int?,
    val vitaminA: Int?,

    val calorieGoal: Int? = 0,
    @PrimaryKey(autoGenerate = true)
    val logId: Int = 0,
)

