package com.example.secondnature.mvvm

sealed interface NutritionEvent {
//    data UpsertLog(name, protein, carbs, fats etc ): NutritionEvent
//    data class DeleteLog(val logId: NutritionLog): NutritionEvent
    object ShowLogPage : NutritionEvent
    object HideLogPage : NutritionEvent
    object GoToDashboard : NutritionEvent
    object GoToAchievements : NutritionEvent
    data class SetName(val new_name : String) : NutritionEvent
    data class SetProtein(val new_protein: Int) : NutritionEvent
    data class SetCarbs(val new_carbs: Int) : NutritionEvent
    data class SetFats(val new_fats: Int) : NutritionEvent
    data class SetVitaminA(val new_vitaminA: Int) : NutritionEvent
    data class SetTransFats(val new_transFats: Int) : NutritionEvent
    data class SetIron(val new_iron: Int) : NutritionEvent

    object SaveLog : NutritionEvent

}