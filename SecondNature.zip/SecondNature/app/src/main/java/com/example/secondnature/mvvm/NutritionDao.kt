package com.example.secondnature.mvvm

import androidx.room.*
import androidx.room.Dao
import kotlinx.coroutines.flow.Flow

//could have multiple DAOs

@Dao
interface NutritionDao {

    @Update
    suspend fun updateUserData(userData: UserData)

    // suspend - allow these functions to run in co-routines. run in background thread.
    // use suspend when data isn't returned.
    //necessary for creating Flow later on

    //must also cause change in Achievements
    @Query("UPDATE NutritionLog" +
            " SET name = :name , protein = :protein," +
            "carbs = :carbs, fats = :fats," +
            "transFats = :transFats, vitaminA = :vitaminA," +
            "date = :date, iron = :iron, calorieGoal = :calorieGoal"
    )
    suspend fun upsertLog(
        name: String?,
        date: Long?,
        protein: Int?,
        carbs: Int?,
        fats: Int?,
        transFats: Int?,
        vitaminA: Int?,
        iron : Int?,
        calorieGoal: Int?,
        //logId: Int
    )

    @Query("SELECT * FROM NutritionLog")
    fun getLogs() : List<NutritionLog>

    @Delete
    suspend fun deleteLog(nutritionLog: NutritionLog)

    @Query("SELECT * FROM NutritionLog WHERE NutritionLog.date = :n_date ")
    fun getLogByDate(n_date: Long) : Flow<List<NutritionLog>>

    @Query ("SELECT * FROM Achievements ORDER BY startDate DESC")
    fun getAchievementsOrderedByDate (): Flow<List<Achievements>>




    //a func that can get all the items for a day
    //Flow - an observable. when there is a change in table, ViewModel is notified.
    //List<T> - List of the records in NutritionLog table.
}