import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.compose.AppTheme

@Composable
fun Initial_Section_Button(name:String){
    Button(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth(),
        onClick = {/*TODO*/ },
        content = { Text(text = name) }
    )
}

@Composable
fun Initial_Dashboard(){
    //placeholder for function that will return a user's daily score
    val score:Int = 99
    Column{
        Text(
            modifier = Modifier
                .align(Alignment.Start),
            text = "Score: $score",
        )
        Column(modifier = Modifier.fillMaxSize()) {
            Initial_Section_Button("Food Diary")
            Initial_Section_Button("Achievements")
            Initial_Section_Button("Settings")
            Initial_Section_Button("Goals")
        }
    }

}


